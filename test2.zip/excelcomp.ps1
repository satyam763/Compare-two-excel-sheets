﻿$reference = Import-Csv -Path D:\Dev\test1.csv
$lookup = $reference | Group-Object -AsHashTable -AsString -Property Server
$resultsNote = "NotMatching"
$resultsNote1 = "Matching"

$results = Import-Csv -Path D:\Dev\test2.csv | foreach {
    $server = $_.Server
    Write-Verbose "Looking for $server"
    if ($lookup.ContainsKey($server))
    {
        $oldState = ($lookup[$server]).State
    }
    else
    {
        $oldState = "NotMatching"
    }
    if ($_.State -ne $oldState)
    {
        [PSCustomObject]@{
            Server = $server
            ResultNote = $resultsNote
        }
    }
    else
    {
        [PSCustomObject]@{
            Server = $server
            ResultNote = $resultsNote1

        }
    }
}

# Sample outputs
$results | Export-Csv -Path D:\Dev\result.csv -NoType -Encoding ASCII